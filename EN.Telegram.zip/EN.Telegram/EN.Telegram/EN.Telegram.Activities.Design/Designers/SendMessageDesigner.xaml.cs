namespace EN.Telegram.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for SendMessageDesigner.xaml
    /// </summary>
    public partial class SendMessageDesigner
    {
        public SendMessageDesigner()
        {
            InitializeComponent();
        }
    }
}
