namespace EN.Telegram.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for TelegramScopeDesigner.xaml
    /// </summary>
    public partial class TelegramScopeDesigner
    {
        public TelegramScopeDesigner()
        {
            InitializeComponent();
        }
    }
}
