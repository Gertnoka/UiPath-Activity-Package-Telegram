namespace EN.Telegram.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for SendPhotoDesigner.xaml
    /// </summary>
    public partial class SendPhotoDesigner
    {
        public SendPhotoDesigner()
        {
            InitializeComponent();
        }
    }
}
