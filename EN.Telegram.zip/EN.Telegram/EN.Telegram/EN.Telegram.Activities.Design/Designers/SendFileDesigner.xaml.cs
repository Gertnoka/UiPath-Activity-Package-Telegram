namespace EN.Telegram.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for SendFileDesigner.xaml
    /// </summary>
    public partial class SendFileDesigner
    {
        public SendFileDesigner()
        {
            InitializeComponent();
        }
    }
}
