﻿namespace UiPath.Shared.Localization
{
    internal class SharedResources : EN.Telegram.Properties.Resources
    {
    }
}